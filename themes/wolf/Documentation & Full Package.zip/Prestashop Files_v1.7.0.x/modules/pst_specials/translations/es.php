<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{pst_specials}prestashop>pst_specials_1276c482cb32edf4fce51761a9792716'] = 'productos especiales';
$_MODULE['<{pst_specials}prestashop>pst_specials_1d8c614a374d5e99617f63706e53c2b0'] = 'Ver más productos';
