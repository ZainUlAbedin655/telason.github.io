<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{pst_specials}prestashop>pst_specials_cffc3a7ef1450a70991313df9a0898ee'] = 'L\'affaire du jour';
$_MODULE['<{pst_specials}prestashop>pst_specials_1d8c614a374d5e99617f63706e53c2b0'] = 'Voir plus de produits';
