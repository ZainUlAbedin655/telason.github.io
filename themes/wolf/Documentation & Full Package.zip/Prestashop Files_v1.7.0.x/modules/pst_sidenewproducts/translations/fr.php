<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{pst_sidenewproducts}prestashop>pst_sidenewproducts_1529636c2dd134b028a08f7b131115b5'] = 'Nouveaux produits';
$_MODULE['<{pst_sidenewproducts}prestashop>pst_sidenewproducts_a40de094ebb292b72fa2a4f3a1cf1209'] = 'Tous les produits';
