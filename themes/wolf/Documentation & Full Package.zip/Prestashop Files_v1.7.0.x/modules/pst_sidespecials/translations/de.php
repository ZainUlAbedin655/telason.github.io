<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{pst_sidespecials}prestashop>pst_sidespecials_1276c482cb32edf4fce51761a9792716'] = 'Spezielle Produkte';
$_MODULE['<{pst_sidespecials}prestashop>pst_sidespecials_a40de094ebb292b72fa2a4f3a1cf1209'] = 'Alle Produkte';
