<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{pst_sidefeaturedproducts}prestashop>pst_sidefeaturedproducts_cf8156f1f57a8603cd6b3a28c9c2c61b'] = 'produits présentés';
$_MODULE['<{pst_sidefeaturedproducts}prestashop>pst_sidefeaturedproducts_a40de094ebb292b72fa2a4f3a1cf1209'] = 'Tous les produits';
