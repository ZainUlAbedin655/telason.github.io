<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{pst_bestsellers}prestashop>pst_bestsellers_9c60b0015478521b72d760da6157b6b1'] = 'Ver mais produtos';
