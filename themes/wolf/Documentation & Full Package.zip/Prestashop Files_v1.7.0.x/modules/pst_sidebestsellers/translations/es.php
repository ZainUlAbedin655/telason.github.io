<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{pst_sidebestsellers}prestashop>pst_sidebestsellers_d7b2933ba512ada478c97fa43dd7ebe6'] = 'Best Sellers';
$_MODULE['<{pst_sidebestsellers}prestashop>pst_sidebestsellers_a40de094ebb292b72fa2a4f3a1cf1209'] = 'Todos los productos';
