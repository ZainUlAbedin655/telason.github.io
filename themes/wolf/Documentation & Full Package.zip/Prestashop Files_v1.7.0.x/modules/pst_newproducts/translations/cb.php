<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{pst_newproducts}prestashop>pst_newproducts_9c60b0015478521b72d760da6157b6b1'] = 'Ver más productos';
